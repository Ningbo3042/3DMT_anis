%*************************** plot*********************************************
    x=unique(xy0{1,1}(1,:));
    y=unique(xy0{1,2}(:,1));
%
figure(1)
subplot(1,4,1)
h1=pcolor(x,y,ResXX);
h=colorbar; %
 set(h1,'LineStyle','none');
title('\rho_{xx}')

ylabel('y/km');
xlabel('x/km');
% axis([-8 8 -8 8])
% caxis([0 5])
% set(gca,'xaxislocation','top');
set(get(h,'Title'),'string','{\Omega}{\bullet}m')
subplot(1,4,2)
h1=pcolor(x,y,ResXY);
h=colorbar; %
set(h1,'LineStyle','none');
title('\rho_{xy}')
xlabel('x/km');
% axis([-8 8 -8 8])
% caxis([90 150])
% ylabel('y/m');
% set(gca,'xaxislocation','top');
set(get(h,'Title'),'string','{\Omega}{\bullet}m')
subplot(1,4,3)
h1=pcolor(x,y,ResYX);
h=colorbar; %
set(h1,'LineStyle','none');
title('\rho_{yx}')
xlabel('x/km');
% ylabel('y/m');
% set(gca,'xaxislocation','top');
set(get(h,'Title'),'string','{\Omega}{\bullet}m')
% caxis([80 160])
% axis([-8 8 -8 8])
subplot(1,4,4)
h1=pcolor(x,y,ResYY);
h=colorbar; %
set(h1,'LineStyle','none');
title('\rho_{yy}')
xlabel('x/km');
% ylabel('y/m');
% caxis([0 5])
% set(gca,'xaxislocation','top');
set(get(h,'Title'),'string','{\Omega}{\bullet}m')
