function [x,y,z,nAir,x0,y0,rho,angle_S,angle_D,angle_L,fre] = read_model(fname)
% reads a 3D resistivity model 
% clear
% input
% fname='model_1.ws';
% output
% x: The length of each unit in x direction
% y: The length of each unit in y direction
% z: The length of each unit in z direction
% Nair: Number of air layers
% x0 and y0 are coordinate of measuring point along x and y directions
% rho(:,1:3) are the three principal axis resistivity of all elements, respectively
% angle_S,angle_D,angle_L are the three Euler angles of all elements, respectively
% fre are the computational frequencies

fid = fopen(fname);
line = fgetl(fid); % comment
line = fgetl(fid);
[n] = sscanf(line,'%d',[4 1]);
nx =   n(1);   ny  =   n(2);   nz  =   n(3);  nAir  =   n(4);

x   =   (fscanf(fid,'%f',nx))';
y   =   (fscanf(fid,'%f',ny))';
z   =   (fscanf(fid,'%f',nz))';
[nre] = fscanf(fid,'%d',[3 1]);
nrex=nre(1);nrey=nre(2);nfre=nre(3);
x0   =   fscanf(fid,'%f',nrex);
y0   =   fscanf(fid,'%f',nrey);
fre  =   fscanf(fid,'%f',nfre);
line = fscanf(fid,'%s',6);
ne=nx*ny*nz;
rho_angle = fscanf(fid,'%f',[6,ne]);
rho=rho_angle(1:3,:)';%rhox,rhoy,rhoz
angle_S=rho_angle(4,:)'*(pi/180);
angle_D=rho_angle(5,:)'*(pi/180);
angle_L=rho_angle(6,:)'*(pi/180);
end
