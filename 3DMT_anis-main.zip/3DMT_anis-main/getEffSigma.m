function A=getEffSigma(sigma)
%computes effective azimuthal anisotropic (see Josef Pek et al., 2002). conductivity
A.xx = sigma(:,1) - (sigma(:,5).^2) ./ sigma(:,3);
A.yy = sigma(:,2) - (sigma(:,6).^2) ./ sigma(:,3);
A.xy = sigma(:,4) - (sigma(:,5) .* sigma(:,6)) ./ sigma(:,3);
