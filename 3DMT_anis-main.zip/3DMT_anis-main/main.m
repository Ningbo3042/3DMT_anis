%%%%%%%% This code is an finite element modeling program  for solving the 3D MT problem in anisotropic media based on Ungauged method .   
%   This code is freely available under the following conditions:
%   1) The code is to be used only for non-commercial purposes.
%   2) No changes and modifications to the code without prior permission of the developer.
%   3) No forwarding the code to a third party without prior permission of the developer.
%   Author information:
%    Dr. Ningbo Bai,  
%    China University of Geosciences
%    bnb3042@163.com  
clc
clear all
format long 
% addpath E:\code\ad=60
fname='E:\code\examples\as=60\3Dansmodel.ws';%% Model data file
% read model data file
fprintf('%s \n','Stage1:read model data file');
readmodel_data;%%Read model input file
solver='B';    %'Q' represents the QMR iterative solver
               %'B' represents the BICGSTAB iterative solver
[XYZ,ME,MEN]=get_matrix_index(NX,NY,NZ,A_X,B_Y,C_Z);% The index matrix of edges and nodes of all elements is obtained
mu=(4e-7)*pi;
epsilo0=8.8542*(10^(-12));
for ff=1:size(fre,2)
w(ff)=2*pi*fre(ff);
fprintf('%s \n','Stage2:produce the global matrix');
Kmatrix  =get_matrix(NE,w,rho,angle_S,angle_D,angle_L,mu,ME,NP,NL,MEN);% Calculating stiffness matrix
fprintf('%s \n','Stage3:get the boundary conditions');
[Ex1,Ex2,Ey1,Ey2]=get_boundary(NX,NY,NZ,C_Z,rho,fre(ff),angle_S,angle_D,angle_L);% The boundary fields of the two modes are calculated
fprintf('%s \n','Stage4:Calculation of (E,H) field in XY mode');
[Exx1,Eyy1,Hxx1,Hyy1]=get_XY(Kmatrix,NX,NY,NZ,XYZ,w(ff),mu,A_X,B_Y,C_Z,NP,NL,Nair,Ex1,Ey1,xy,xy0,solver);
fprintf('%s \n','Stage5:Calculation of (E,H) field in YX mode');
[Exx2,Eyy2,Hxx2,Hyy2]=get_YX(Kmatrix,NX,NY,NZ,XYZ,w(ff),mu,A_X,B_Y,C_Z,NP,NL,Nair,Ex2,Ey2,xy,xy0,solver);
fprintf('%s \n','Stage6: Calculate resistivity and impedance phase');
%%%%% Calculate impedance, apparent resistivity and phase.%%%%%%%
    for i=1:ny
        for j=1:nx
        
                        Temp=Hxx1(i,j)*Hyy2(i,j)-Hyy1(i,j)*Hxx2(i,j);
                        Zxx(i,j)=( Exx1(i,j)*Hyy2(i,j)- Exx2(i,j)*Hyy1(i,j))/Temp;
                        Zxy(i,j)=( Exx2(i,j)*Hxx1(i,j)- Exx1(i,j)*Hxx2(i,j))/Temp;
                        Zyx(i,j)=( Eyy1(i,j)*Hyy2(i,j)-Eyy2(i,j)*Hyy1(i,j))/Temp;
                        Zyy(i,j)=(Eyy2(i,j)*Hxx1(i,j)-Eyy1(i,j)*Hxx2(i,j))/Temp;
                        PhaseXY(i,j)=-atan(imag(Zxy(i,j))/real(Zxy(i,j)))*180/pi;
                        PhaseYX(i,j)=-atan(imag(Zyx(i,j))/real(Zyx(i,j)))*180/pi;
                        ResYX(i,j)=abs((Zyx(i,j))^2*sqrt(-1)/(2*pi*fre(ff)*mu));
                        ResXY(i,j)=abs((Zxy(i,j))^2*sqrt(-1)/(2*pi*fre(ff)*mu));
                        ResXX(i,j)=abs((Zxx(i,j))^2*sqrt(-1)/(2*pi*fre(ff)*mu));
                        ResYY(i,j)=abs((Zyy(i,j))^2*sqrt(-1)/(2*pi*fre(ff)*mu));
        end
    end
end
%%%%%%%%%%%%%%%%%%%%plot%%%%%%%%%%%%%%%%%%%%%%%%%%%
     painting1





    






