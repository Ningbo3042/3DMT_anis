function [XYZ,ME,MEN]=get_matrix_index(NX,NY,NZ,A_X,B_Y,C_Z)
%input:
% NX: The numbers in x direction
% NY: The numbers in y direction
% NZ: The numbers in z direction
% A_X: The length of each unit in x direction
% B_Y: The length of each unit in y direction
% C_Z: The length of each unit in z direction
%output:
%XYZ:Node number corresponding to each layer
%ME: node index of all cell 
%MEN:ledge index of all cell
i=0;
for ll=1:NZ+1
    for mm=1:NY+1
        for nn=1:NX+1
            i=i+1;
            XYZ(1:3,i)=[nn mm ll]  ;
        end
    end
end

%%% Number of all cell nodes
for l = 1:NZ
    for m = 1:NY
           n = 1:NX;
        ME(1,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n;
        ME(2,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+1;
        ME(3,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+NX+2;
        ME(4,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+NX+1;
        ME(5,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+(NX+1)*(NY+1);
        ME(6,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+1+(NX+1)*(NY+1);
        ME(7,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+NX+2+(NX+1)*(NY+1);
        ME(8,(l-1)*NY*NX+(m-1)*NX+n)= (l-1)*(NY+1)*(NX+1)+(m-1)*(NX+1)+n+NX+1+(NX+1)*(NY+1);
        ME(9,(l-1)*NY*NX+(m-1)*NX+n)=A_X(n);% x
        ME(10,(l-1)*NY*NX+(m-1)*NX+n)=B_Y(m);%y
        ME(11,(l-1)*NY*NX+(m-1)*NX+n)=C_Z(l);%z
    end
end
%%%  Number of all cell edges
for L=1:NZ                
    for M=1:NY
        for N=1:NX
            IL1=(L-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1));
            MEN(1,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N;
            MEN(2,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+2*NX+1;
            MEN(3,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1);
            MEN(4,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1)+2*NX+1;
            MEN(5,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX;
            MEN(6,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX+NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1);
            MEN(7,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX+1;
            MEN(8,(L-1)*NY*NX+(M-1)*NX+N)=IL1+(M-1)*(2*NX+1)+N+NX+1+NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1);
            MEN(9,(L-1)*NY*NX+(M-1)*NX+N)=IL1+NX*(NY+1)+NY*(NX+1)+(M-1)*(NX+1)+N;
            MEN(10,(L-1)*NY*NX+(M-1)*NX+N)=IL1+NX*(NY+1)+NY*(NX+1)+(M-1)*(NX+1)+N+1;
            MEN(11,(L-1)*NY*NX+(M-1)*NX+N)=IL1+NX*(NY+1)+NY*(NX+1)+(M-1)*(NX+1)+N+1+NX;
            MEN(12,(L-1)*NY*NX+(M-1)*NX+N)=IL1+NX*(NY+1)+NY*(NX+1)+(M-1)*(NX+1)+N+2+NX;
        end
    end
end