function [Exx2,Eyy2,Hxx2,Hyy2]=get_YX(v2,NX,NY,NZ,XYZ,w,mu,A_X,B_Y,C_Z,NP,NL,Nair,Ex2,Ey2,xy,xy0,solver)
%Input
% NX: The numbers in x direction
% NY: The numbers in y direction
% NZ: The numbers in z direction
% A_X: The length of each unit in x direction
% B_Y: The length of each unit in y direction
% C_Z: The length of each unit in z direction
% Nair: Number of air layers
% xy0 and yx0 are coordinate of measuring point.
% xy and yx are the calculated coordinates of the area.
% rho(:,1:3) are the three principal axis resistivity of all elements, respectively
% angle_S,angle_D,angle_L are the three Euler angles of all elements, respectively
% fre are the computational frequencies
% v2 is a sparse stiffness matrix
% Ex2 and Ey2 are EM fields obtained by 1D analytical solution of electric field, respectively
% Output
%Exx2, Eyy2, Hxx2, and Hyy2 are the electromagnetic fields at the receiving point respectively.
%% Index the edges and node numbers of the boundary, and load the boundary conditions for YX mode
ExA=(Ex2).'./(sqrt(-1)*w);
EyA=(Ey2).'./(sqrt(-1)*w);
EzA(1:NZ+1)=0;
b2=zeros(NL+NP,1);
    idn=0;
    for j=1:NY+1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=(j-1)*(NX+NX+1)+i;
             b2(Bid(idn))=ExA(1);
        end
    end

    for k=1:NZ-1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+i;
            b2(Bid(idn))=ExA(k+1);
        end
        for i=1:NX
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+NY*(NX+1)+NX*NY+i;
            b2(Bid(idn))=ExA(k+1);
        end
    end
   for j=1:NY+1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=NZ*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+i;
            b2(Bid(idn))=ExA(NZ+1);
        end
    end
    for j=1:NY
        for i=1:NX+1
            idn=idn+1;
            Bid(idn)=(j-1)*(NX+NX+1)+NX+i;
            b2(Bid(idn))=EyA(1);
        end
    end
    for k=1:NZ-1
        for j=1:NY
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+1;
            b2(Bid(idn))=EyA(k+1);
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+NX+1;
            b2(Bid(idn))=EyA(k+1);
        end
    end
    for j=1:NY
        for i=1:NX+1
            idn=idn+1;
            Bid(idn)=NZ*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+i;
            b2(Bid(idn))=EyA(NZ+1);
        end
    end

    for k=1:NZ
        for j=1:1
            for i=1:NX+1
                idn=idn+1;
                Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+i;
                b2(Bid(idn))=EzA(k);
            end
        end
        for j=2:NY
            idn=idn+1;
            Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+(j-1)*(NX+1)+1;
            b2(Bid(idn))=EzA(k);
            idn=idn+1;
            Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+j*(NX+1);
            b2(Bid(idn))=EzA(k);
        end
        for j=NY+1:NY+1
            for i=1:NX+1
                idn=idn+1;
                Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+(NX+1)*NY+i;
                b2(Bid(idn))=EzA(k);
            end
        end
    end

     iphitop=(1:(NY+1)*(NX+1))+NL;%
     Bid=[Bid iphitop];
  for i=1:NZ-1
      iphimiddle1=[i*(NY+1)*(NX+1)+(1:(NX+1)) i*(NY+1)*(NX+1)+NY*(NX+1)+(1:(NX+1))];%
      Bid=[Bid iphimiddle1+NL];%   
  end
   for i=1:NZ-1
      for j=2:NY
         iphimiddle2=[i*(NY+1)*(NX+1)+(j-1)*(NX+1)+1 i*(NY+1)*(NX+1)+(j-1)*(NX+1)+NX+1];%
         Bid=[Bid iphimiddle2+NL];%     
      end
  end    
  iphibot=(NZ*(NY+1)*(NX+1)+1:(NX+1)*(NY+1)*(NZ+1));
  Bid=[Bid iphibot+NL];

Bdirc=Bid';

p2=b2;
b2=b2-v2(:,Bdirc(:,1))*b2(Bdirc(:,1));
b2(Bdirc(:,1))=p2(Bdirc(:,1));
v2(Bdirc(:,1),:)=0;
v2(:,Bdirc(:,1))=0;
ii=Bdirc(:,1);
Kbnd=sparse(ii,ii,ones(size(ii)),NL+NP,NL+NP);
v2=v2+Kbnd;
%% Solve the sparse matrix for YX mode
tol=1e-7;maxsteps=3000;
setup.type='nofill';
[L,U]=ilu(v2,setup);
tic
if strcmp(solver,'Q')
    [x,flag,relres,iter3,resvec1]=qmr(v2,b2,tol,maxsteps,L,U);
elseif strcmp(solver,'B')
    [x,flag,relres,iter3,resvec1]=bicgstab(v2,b2,tol,maxsteps,L,U);
end
 time2=toc
res2=resvec1/norm(b2);
save res2 res2 time2
clear v2
%% Calculate the EH field at the receiving point for YX mode
%%%%%%%% Ax %%%%%%%%%%%%%
    Ax2=zeros(NX,NY+1,NZ+1);
    for k=1:NZ+1
        for j=1:NY+1
            for i=1:NX
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+(j-1)*(2*NX+1)+i;
                Ax2(i,j,k)=x(MEij);
            end
        end
    end
    %%%%%%%%% Ay %%%%%%%%%%%%%
    Ay2=zeros(NX+1,NY,NZ+1);
    for k=1:NZ+1
        for i=1:NX+1
            for j=1:NY
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+(j-1)*(2*NX+1)+NX+i;
                Ay2(i,j,k)=x(MEij);
            end
        end
    end
    %%%%%%%%% Az %%%%%%%%%%%%%
    Az2=zeros(NX+1,NY+1,NZ);
    for k=1:NZ
        for i=1:NX+1
            for j=1:NY+1
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+NX*(NY+1)+NY*(NX+1)+(j-1)*(NX+1)+i;
                Az2(i,j,k)=x(MEij);
            end
        end
    end

  for i=1:NP
     PHI2(XYZ(1,i),XYZ(2,i),XYZ(3,i))=x(NL+i);
  end
  
    for i=1:NX %x 
        for j=1:NY % y
            Azx2(i,j)=(Az2(i+1,j,Nair+1)-Az2(i,j,Nair+1)+Az2(i+1,j+1,Nair+1)-Az2(i,j+1,Nair+1))/2.d0/A_X(i);
            Axz2(i,j)=(Ax2(i,j,Nair+2)-Ax2(i,j,Nair+1)+Ax2(i,j+1,Nair+2)-Ax2(i,j+1,Nair+1))/2.d0/C_Z(Nair+1);
            Ayx2(i,j)=(Ay2(i+1,j,Nair+1)-Ay2(i,j,Nair+1)+Ay2(i+1,j,Nair+2)-Ay2(i,j,Nair+2))/2.d0/A_X(i);
            Axy2(i,j)=(Ax2(i,j+1,Nair+1)-Ax2(i,j,Nair+1)+Ax2(i,j+1,Nair+2)-Ax2(i,j,Nair+2))/2.d0/B_Y(j);
            Azy2(i,j)=(Az2(i,j+1,Nair+1)-Az2(i,j,Nair+1)+Az2(i+1,j+1,Nair+1)-Az2(i+1,j,Nair+1))/2.d0/B_Y(j);
            Ayz2(i,j)=(Ay2(i+1,j,Nair+2)-Ay2(i+1,j,Nair+1)+Ay2(i,j,Nair+2)-Ay2(i,j,Nair+1))/2.d0/C_Z(Nair+1);
            Exx0(i,j)=(sqrt(-1)*w).*(((Ax2(i,j+1,Nair+1)+Ax2(i,j,Nair+1))/2.d0+(Ax2(i,j+1,Nair+2)+Ax2(i,j,Nair+2))/2.d0)/2.d0+((PHI2(i+1,j,Nair+1)-PHI2(i,j,Nair+1))/A_X(i)+(PHI2(i+1,j+1,Nair+1)-PHI2(i,j+1,Nair+1))/A_X(i))/2); %  ���Ĵų�ȡΪ��Ԫ�ĸ��ڵ�ų���ƽ��ֵ
            Eyy0(i,j)=(sqrt(-1)*w).*(((Ay2(i,j,Nair+1)+Ay2(i+1,j,Nair+1))/2.d0+(Ay2(i,j,Nair+2)+Ay2(i+1,j,Nair+2))/2.d0)/2.d0+((PHI2(i,j+1,Nair+1)-PHI2(i,j,Nair+1))/B_Y(j)+(PHI2(i+1,j+1,Nair+1)-PHI2(i+1,j,Nair+1))/B_Y(j))/2); %  ���Ĵų�ȡΪ��Ԫ�ĸ��ڵ�ų���ƽ��ֵ
            Hyy0(i,j)=( Axz2(i,j)-Azx2(i,j))/((mu));%  
            Hxx0(i,j)=(Azy2(i,j)-Ayz2(i,j))/((mu));           
        end
    end

    Exx2=interp2(xy{1,1},xy{1,2},Exx0.',xy0{1,1},xy0{1,2},'spline');
    Hxx2=interp2(xy{1,1},xy{1,2},Hxx0.',xy0{1,1},xy0{1,2},'spline');
    Eyy2=interp2(xy{1,1},xy{1,2},Eyy0.',xy0{1,1},xy0{1,2},'spline');
    Hyy2=interp2(xy{1,1},xy{1,2},Hyy0.',xy0{1,1},xy0{1,2},'spline');
end
  

   
   
   