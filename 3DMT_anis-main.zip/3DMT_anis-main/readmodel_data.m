                %%%%%%%%%%read model data%%%%%%%%%   
% reads a 3D resistivity model               
[A_X,B_Y,C_Z,Nair,x0,y0,rho,angle_S,angle_D,angle_L,fre] = read_model(fname); %read model file
%Output
% A_X: The length of each unit in x direction
% B_Y: The length of each unit in y direction
% C_Z: The length of each unit in z direction
% Nair: Number of air layers
% x0 and y0 are coordinate of measuring point along x and y directions
% rho(:,1:3) are the three principal axis resistivity of all elements, respectively
% angle_S,angle_D,angle_L are the three Euler angles of all elements, respectively
% fre are the computational frequencies
NX=length(A_X);
NY=length(B_Y);
NZ=length(C_Z); 
NE=NX*NY*NZ; %
NL=NX*(NY+1)*(NZ+1)+(NX+1)*NY*(NZ+1)+(NX+1)*(NY+1)*NZ;
NP=(NX+1)*(NY+1)*(NZ+1);
[xy,xy0,nx,ny]=get_location(A_X,B_Y,x0,y0);  %%get the coordinates of the measured points
fprintf('%s \n','Setting of model parameters is completed');
fprintf('%s%d \n','The number of calculated frequences :',fre);
fprintf('%s%d \n','The number of calculated elements :',NE);
fprintf('%s%d \n','The calculated model size ::',NL+NP);
