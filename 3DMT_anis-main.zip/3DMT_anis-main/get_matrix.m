function Kmatrix  =get_matrix(NE,w,rho,A_S,A_D,A_L,mu,MEN,NP,NL,ME)
  %%%%%%%%%%%%%%
  %Input
  % rho(:,1:3) are the three principal axis resistivity of all elements, respectively
  % A_S,A_D,A_L are the three Euler angles of all elements, respectively
  % MEN and ME are the edge number and node number of the elements, respectively
  % NP,NL and NE are the number of nodes, edges and elements, respectively
  % Output
  % Kmatrix is the sparse stiffness matrix
  
 %% Coefficient matrix in Appendix 1 (A22) - A(26)
ka=[4 -4 -2 2 2 -2 -1 1;-4 4 2 -2 -2 2 1 -1;
     -2 2 4 -4 -1 1 2 -2;2 -2 -4 4 1 -1 -2 2;
     2 -2 -1 1 4 -4 -2 2;-2 2 1 -1 -4 4 2 -2;
     -1 1 2 -2 -2 2 4 -4;1 -1 -2 2 2 -2 -4 4];
kb=[6 -6 -6 6 3 -3 -3 3;6 -6 -6 6 3 -3 -3 3;
     -6 6 6 -6 -3 3 3 -3;-6 6 6 -6 -3 3 3 -3;
      3 -3 -3 3 6 -6 -6 6;3 -3 -3 3 6 -6 -6 6;
     -3 3 3 -3 -6 6 6 -6;-3 3 3 -3 -6 6 6 -6];
kc=[6 -6 -3 3 6 -6 -3 3;6 -6 -3 3 6 -6 -3 3;
      3 -3 -6 6 3 -3 -6 6;3 -3 -6 6 3 -3 -6 6;
     -6 6 3 -3 -6 6 3 -3;-6 6 3 -3 -6 6 3 -3;
     -3 3 6 -6 -3 3 6 -6;-3 3 6 -6 -3 3 6 -6];
kd=[6 6 -6 -6 3 3 -3 -3;-6 -6 6 6 -3 -3 3 3;
     -6 -6 6 6 -3 -3 3 3;6 6 -6 -6 3 3 -3 -3;
      3 3 -3 -3 6 6 -6 -6;-3 -3 3 3 -6 -6 6 6;
     -3 -3 3 3 -6 -6 6 6;  3 3 -3 -3 6 6 -6 -6];
ke=[4 2 -2 -4 2 1 -1 -2;2 4 -4 -2 1 2 -2 -1;
      -2 -4 4 2 -1 -2 2 1;-4 -2 2 4  -2 -1 1 2;
      2 1 -1 -2 4 2 -2 -4;1 2 -2 -1 2 4 -4 -2;
     -1 -2 2 1 -2 -4 4 2;-2 -1 1 2 -4 -2 2 4];
kf=[6 3 -3 -6 6 3 -3 -6;3 6 -6 -3 3 6 -6 -3;
      3 6 -6 -3 3 6 -6 -3;6 3 -3 -6 6 3 -3 -6;
     -6 -3 3 6 -6 -3 3 6;-3 -6 6 3 -3 -6 6 3;
     -3 -6 6 3 -3 -6 6 3;-6 -3 3 6 -6 -3 3 6];
kg=[6 6 3 3 -6 -6 -3 -3;-6 -6 -3 -3 6 6 3 3;
     -3 -3 -6 -6 3 3 6 6;3 3 6 6 -3 -3 -6 -6;
     6 6 3 3 -6 -6 -3 -3;-6 -6 -3 -3 6 6 3 3;
     -3 -3 -6 -6 3 3 6 6;3 3 6 6 -3 -3 -6 -6];
kh=[6 3 3 6 -6 -3 -3 -6;3 6 6 3 -3 -6 -6 -3;
     -3 -6 -6 -3 3 6 6 3;-6 -3 -3 -6 6 3 3 6;
     6 3 3 6 -6 -3 -3 -6;3 6 6 3 -3 -6 -6 -3;
    -3 -6 -6 -3 3 6 6 3;-6 -3 -3 -6 6 3 3 6];
ki=[4 2 1 2 -4 -2 -1 -2;2 4 2 1 -2 -4 -2 -1;
      1 2 4 2 -1 -2 -4 -2;2 1 2 4 -2 -1 -2 -4;
     -4 -2 -1 -2 4 2 1 2;-2 -4 -2 -1 2 4 2 1;
     -1 -2 -4 -2 1 2 4 2;-2 -1 -2 -4 2 1 2 4];
%% Calculating  stiffness matrix K
 for h=1:NE
     sigma=[1/rho(h,1) 0 0; 
            0 1/rho(h,2) 0; 
            0 0 1/rho(h,3)];
     Rz_S=[cos(-A_S(h)) sin(-A_S(h)) 0; -sin(-A_S(h)) cos(-A_S(h)) 0; 0 0 1]; 
     Rx_D=[1 0 0; 0 cos(-A_D(h)) sin(-A_D(h)); 0 -sin(-A_D(h)) cos(-A_D(h))]; 
     Rz_L=[cos(-A_L(h)) sin(-A_L(h)) 0; -sin(-A_L(h)) cos(-A_L(h)) 0; 0 0 1]; 
     Rz_LT=[cos(A_L(h)) sin(A_L(h)) 0; -sin(A_L(h)) cos(A_L(h)) 0; 0 0 1]; 
     Rx_DT=[1 0 0; 0 cos(A_D(h)) sin(A_D(h)); 0 -sin(A_D(h)) cos(A_D(h))]; 
     Rz_ST=[cos(A_S(h)) sin(A_S(h)) 0; -sin(A_S(h)) cos(A_S(h)) 0; 0 0 1]; 
     sig_tensor=Rz_S*Rx_D*Rz_L*sigma*Rz_LT*Rx_DT*Rz_ST;
     a=MEN(9,h);
     b=MEN(10,h);
     c=MEN(11,h);
% Calculate k11-k44 in Appendix 1     
     % Calculate k11,k12,k13,k21,k22,k23,k31,k32,k33 in Appendix A (5)
     k11=[ 2,-2, 1,-1;-2, 2,-1, 1;...
           1,-1, 2,-2;-1, 1,-2, 2];
     k12=[ 2, 1,-2,-1;1, 2,-1,-2;...
          -2,-1, 2, 1;-1,-2, 1, 2];     
     k1xx=-a*c/b/6*k11-a*b/c/6*k12;
     k1yy=-a*b/c/6*k11-b*c/a/6*k12;
     k1zz=-b*c/a/6*k11-a*c/b/6*k12;
     kz=zeros(4,4);
     k1e=[k1xx   kz     kz;...
          kz     k1yy   kz;...
          kz     kz     k1zz];
     k2xx=sqrt(-1)*w*mu*a*b*c/36*[4 2 2 1;2 4 1 2;...%
                                  2 1 4 2;1 2 2 4]; 
     k2xy=sqrt(-1)*w*mu*a*b*c/24*[2 1 2 1;2 1 2 1;...
                                  1 2 1 2;1 2 1 2]; 
     k2xz=sqrt(-1)*w*mu*a*b*c/24*[2 2 1 1;1 1 2 2;...
                                  2 2 1 1;1 1 2 2]; 
     k2yx=sqrt(-1)*w*mu*a*b*c/24*[2 2 1 1;1 1 2 2;...
                                  2 2 1 1;1 1 2 2]; 
     k2yy=sqrt(-1)*w*mu*a*b*c/36*[4 2 2 1;2 4 1 2;...
                                  2 1 4 2;1 2 2 4]; 
     k2yz=sqrt(-1)*w*mu*a*b*c/24*[2 1 2 1;2 1 2 1;...
                                  1 2 1 2;1 2 1 2]; 
     k2zx=sqrt(-1)*w*mu*a*b*c/24*[2 1 2 1;2 1 2 1;...
                                  1 2 1 2;1 2 1 2]; 
     k2zy=sqrt(-1)*w*mu*a*b*c/24*[2 2 1 1;1 1 2 2;
                                  2 2 1 1;1 1 2 2]; 
     k2zz=sqrt(-1)*w*mu*a*b*c/36*[4 2 2 1;2 4 1 2;...
                                  2 1 4 2;1 2 2 4];
    
     k2e=[sig_tensor(1,1)*k2xx sig_tensor(1,2)*k2xy sig_tensor(1,3)*k2xz; ...
          sig_tensor(2,1)*k2yx sig_tensor(2,2)*k2yy sig_tensor(2,3)*k2yz; ...
          sig_tensor(3,1)*k2zx sig_tensor(3,2)*k2zy sig_tensor(3,3)*k2zz];
     Ke1=k1e+k2e;
    % Calculate k14,K24,k34 in Appendix 1 A(5) 
     K14a=sqrt(-1)*w*mu*b*c/36*[-4 4 2 -2 -2 2 1 -1;...
                                -2 2 4 -4 -1 1 2 -2;...%
                                -2 2 1 -1 -4 4 2 -2;...
                                -1 1 2 -2 -2 2 4 -4];
     K14b=sqrt(-1)*w*mu*a*c/24*[-2 -2 2 2 -1 -1 1 1;...
                                -2 -2 2 2 -1 -1 1 1;...
                                -1 -1 1 1 -2 -2 2 2;...
                                -1 -1 1 1 -2 -2 2 2]; 
     K14c=sqrt(-1)*w*mu*a*b/24*[-2 -2 -1 -1 2 2 1 1;...
                                -1 -1 -2 -2 1 1 2 2;...
                                -2 -2 -1 -1 2 2 1 1;...
                                -1 -1 -2 -2 1 1 2 2];
                               
     K24a=sqrt(-1)*w*mu*b*c/24*[-2 2 2 -2 -1 1 1 -1;...
                                -1 1 1 -1 -2 2 2 -2;...
                                -2 2 2 -2 -1 1 1 -1;...
                                -1 1 1 -1 -2 2 2 -2];                       
     K24b=sqrt(-1)*w*mu*a*c/36*[-4 -2 2 4 -2 -1 1 2;...
                                -2 -1 1 2 -4 -2 2 4;...
                                -2 -4 4 2 -1 -2 2 1;...
                                -1 -2 2 1 -2 -4 4 2];
     K24c=sqrt(-1)*w*mu*a*b/24*[-2 -1 -1 -2 2 1 1 2;...
                                -2 -1 -1 -2 2 1 1 2;...
                                -1 -2 -2 -1 1 2 2 1;...
                                -1 -2 -2 -1 1 2 2 1];                               
                              
     K34a=sqrt(-1)*w*mu*b*c/24*[-2 2 1 -1 -2 2 1 -1;...
                                -2 2 1 -1 -2 2 1 -1;...
                                -1 1 2 -2 -1 1 2 -2;...
                                -1 1 2 -2 -1 1 2 -2];
     K34b=sqrt(-1)*w*mu*a*c/24*[-2 -1 1 2 -2 -1 1 2;...
                                -1 -2 2 1 -1 -2 2 1;...
                                -2 -1 1 2 -2 -1 1 2;...
                                -1 -2 2 1 -1 -2 2 1];                        
    K34c=sqrt(-1)*w*mu*a*b/36*[-4 -2 -1 -2 4 2 1 2;...
                               -2 -4 -2 -1 2 4 2 1;...
                               -2 -1 -2 -4 2 1 2 4;...
                               -1 -2 -4 -2 1 2 4 2];                       
    s14factor=sig_tensor(1,1)*K14a+sig_tensor(1,2)*K14b+sig_tensor(1,3)*K14c;%k14
        
    s24factor=sig_tensor(2,1)*K24a+sig_tensor(2,2)*K24b+sig_tensor(2,3)*K24c;%k24
        
    s34factor=sig_tensor(3,1)*K34a+sig_tensor(3,2)*K34b+sig_tensor(3,3)*K34c;%k34
    Ke2=[s14factor;s24factor;s34factor];
    % Calculate 44 in Appendix A(5)
    Ke3=sqrt(-1)*w*mu*[b*c*sig_tensor(1,1)/36/a*ka+c*sig_tensor(2,1)/72*kb+sig_tensor(3,1)*b/72*kc+ ...
                       sig_tensor(1,2)*c/72*kd+a*c*sig_tensor(2,2)/36/b*ke+a*sig_tensor(3,2)/72*kf+...
                       b*sig_tensor(1,3)/72*kg+a*sig_tensor(2,3)/72*kh+a*b*sig_tensor(3,3)/36/c*ki];

    Se1=reshape(Ke1.',12*12,1); 
    Se2=reshape(Ke2.',12*8,1);       
    Se3=reshape(Ke3.',8*8,1);
       
    S1(h:NE:(12*12-1)*NE+h)=Se1;
    S2(h:NE:(12*8-1)*NE+h)= Se2;  
    S3(h:NE:(8*8-1)*NE+h)= Se3;
 end
%% The sparse stiffness matrix is assembled by indexing the edges and nodes of the element

ii=zeros(12*12*NE,1);
jj=zeros(12*12*NE,1);
index=0;
for it1=1:12
    for jt1=1:12
        ii(index+1:index+NE)=ME(it1,:);
        jj(index+1:index+NE)=ME(jt1,:);
        index=index+NE;
    end
end
V1=sparse(ii,jj,S1,NL,NL);
clear ii jj
index=0;
for it1=1:8
    for jt1=1:8
        ii(index+1:index+NE)=MEN(it1,:);
        jj(index+1:index+NE)=MEN(jt1,:);
        index=index+NE;
    end
end
V3=sparse(ii,jj,S3,NP,NP);
clear ii jj
index=0;
for it1=1:12
    for jt1=1:8
        ii(index+1:index+NE)=ME(it1,:);
        jj(index+1:index+NE)=MEN(jt1,:);
        index=index+NE;
    end
end
V2=sparse(ii,jj,S2,NL,NP);
%  Assemble into sparse matrix
Kmatrix=[V1 V2;  V2.' V3]; 
