function b=vet(a)
% Transform matrix a,
N=length(a);
b=reshape(a,N,1);
end
