function [Exx1,Eyy1,Hxx1,Hyy1]=get_XY(v1,NX,NY,NZ,XYZ,w,mu,A_X,B_Y,C_Z,NP,NL,Nair,Ex1,Ey1,xy,xy0,solver)
% input
% NX: The numbers in x direction
% NY: The numbers in y direction
% NZ: The numbers in z direction
% A_X: The length of each unit in x direction
% B_Y: The length of each unit in y direction
% C_Z: The length of each unit in z direction
% Nair: Number of air layers
% xy0 and yx0 are coordinate of measuring point.
% xy and yx are the calculated coordinates of the area.
% rho(:,1:3) are the three principal axis resistivity of all elements, respectively
% angle_S,angle_D,angle_L are the three Euler angles of all elements, respectively
% fre are the computational frequencies
% v1 is a sparse stiffness matrix
% Ex1 and Ey1 are EM fields obtained by 1D analytical solution of electric field, respectively
% output
%Exx1, Eyy1, Hxx1, and Hyy1 are the electromagnetic fields at the receiving point respectively.
%% Index the edges and node numbers of the boundary, and load the boundary conditions for XY mode
ExB=(Ex1).'./(sqrt(-1)*w);
EyB=(Ey1).'./(sqrt(-1)*w);
EzB(1:NZ+1)=0;
b1=zeros(NL+NP,1);
    idn=0;
    for j=1:NY+1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=(j-1)*(NX+NX+1)+i;
            b1(Bid(idn))=ExB(1);
        end
    end
    for k=1:NZ-1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+i;
            b1(Bid(idn))=ExB(k+1);
        end
        for i=1:NX
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+NY*(NX+1)+NX*NY+i;
            b1(Bid(idn))=ExB(k+1);
        end
    end
    for j=1:NY+1
        for i=1:NX
            idn=idn+1;
            Bid(idn)=NZ*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+i;
            b1(Bid(idn))=ExB(NZ+1);
        end
    end
    for j=1:NY
        for i=1:NX+1
            idn=idn+1;
            Bid(idn)=(j-1)*(NX+NX+1)+NX+i;
            b1(Bid(idn))=EyB(1);
        end
    end
    for k=1:NZ-1
        for j=1:NY
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+1;
            b1(Bid(idn))=EyB(k+1);
            idn=idn+1;
            Bid(idn)=k*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+NX+1;
            b1(Bid(idn))=EyB(k+1);
        end
    end
    for j=1:NY
        for i=1:NX+1
            idn=idn+1;
            Bid(idn)=NZ*(NX*(NY+1)+(NX+1)*NY+(NX+1)*(NY+1))+(j-1)*(NX+NX+1)+NX+i;
            b1(Bid(idn))=EyB(NZ+1);
        end
    end
    for k=1:NZ
        for j=1:1
            for i=1:NX+1
                idn=idn+1;
                Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+i;
                b1(Bid(idn))=EzB(k);
            end
        end
        for j=2:NY
            idn=idn+1;
            Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+(j-1)*(NX+1)+1;
            b1(Bid(idn))=EzB(k);
            idn=idn+1;
            Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+j*(NX+1);
            b1(Bid(idn))=EzB(k);
        end
        for j=NY+1:NY+1
            for i=1:NX+1
                idn=idn+1;
                Bid(idn)=(k-1)*((NY+1)*NX+(NX+1)*NY+(NX+1)*(NY+1))+(NY+1)*NX+(NX+1)*NY+(NX+1)*NY+i;
                b1(Bid(idn))=EzB(k);
            end
        end
    end
     iphitop=(1:(NY+1)*(NX+1))+NL;
     Bid=[Bid iphitop];
  for i=1:NZ-1
      iphimiddle1=[i*(NY+1)*(NX+1)+(1:(NX+1)) i*(NY+1)*(NX+1)+NY*(NX+1)+(1:(NX+1))];
      Bid=[Bid iphimiddle1+NL];%       
  end
   for i=1:NZ-1
      for j=2:NY
         iphimiddle2=[i*(NY+1)*(NX+1)+(j-1)*(NX+1)+1 i*(NY+1)*(NX+1)+(j-1)*(NX+1)+NX+1];
         Bid=[Bid iphimiddle2+NL];    
      end
  end    
  iphibot=(NZ*(NY+1)*(NX+1)+1:(NX+1)*(NY+1)*(NZ+1));
  Bid=[Bid iphibot+NL];
Bdirc=Bid';
p1=b1;%
b1=b1-v1(:,Bdirc(:,1))*b1(Bdirc(:,1));
b1(Bdirc(:,1))=p1(Bdirc(:,1));
v1(Bdirc(:,1),:)=0;
v1(:,Bdirc(:,1))=0;
ii=Bdirc(:,1);
Kbnd=sparse(ii,ii,ones(size(ii)),NL+NP,NL+NP);
v1=v1+Kbnd;

%% Solve the sparse matrix for XY mode
tol=1e-7;maxsteps=3000;
setup.type='nofill';
% setup.type='ilutp';setup.droptol=0.001;
[L,U]=ilu(v1,setup);%
tic
if strcmp(solver,'Q')
    [x,flag,relres,iter3,resvec1]=qmr(v1,b1,tol,maxsteps,L,U);
elseif strcmp(solver,'B')
    [x,flag,relres,iter3,resvec1]=bicgstab(v1,b1,tol,maxsteps,L,U);
end
time1=toc;
res1=resvec1/norm(b1);
save res1 res1 time1
clear v1
%% Calculate the EH field at the receiving point for XY mode
%%%%%%%% Ax %%%%%%%%%%%%%
    Ax1=zeros(NX,NY+1,NZ+1);
    for k=1:NZ+1
        for j=1:NY+1
            for i=1:NX
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+(j-1)*(2*NX+1)+i;
                Ax1(i,j,k)=x(MEij);
            end
        end
    end
    %%%%%%%%% Ay %%%%%%%%%%%%%
    Ay1=zeros(NX+1,NY,NZ+1);
    for k=1:NZ+1
        for i=1:NX+1
            for j=1:NY
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+(j-1)*(2*NX+1)+NX+i;
                Ay1(i,j,k)=x(MEij);
            end
        end
    end
    %%%%%%%%% Az %%%%%%%%%%%%%
    Az1=zeros(NX+1,NY+1,NZ);
    for k=1:NZ
        for i=1:NX+1
            for j=1:NY+1
                MEij=(k-1)*(NX*(NY+1)+NY*(NX+1)+(NX+1)*(NY+1))+NX*(NY+1)+NY*(NX+1)+(j-1)*(NX+1)+i;
                Az1(i,j,k)=x(MEij);
            end
        end
    end
  for i=1:NP
     PHI1(XYZ(1,i),XYZ(2,i),XYZ(3,i))=x(NL+i);
  end
  
    for i=1:NX %x 
        for j=1:NY % y
            Azx1(i,j)=(Az1(i+1,j,Nair+1)-Az1(i,j,Nair+1)+Az1(i+1,j+1,Nair+1)-Az1(i,j+1,Nair+1))/2.d0/A_X(i);
            Axz1(i,j)=(Ax1(i,j,Nair+2)-Ax1(i,j,Nair+1)+Ax1(i,j+1,Nair+2)-Ax1(i,j+1,Nair+1))/2.d0/C_Z(Nair+1);
            Ayx1(i,j)=(Ay1(i+1,j,Nair+1)-Ay1(i,j,Nair+1)+Ay1(i+1,j,Nair+2)-Ay1(i,j,Nair+2))/2.d0/A_X(i);
            Axy1(i,j)=(Ax1(i,j+1,Nair+1)-Ax1(i,j,Nair+1)+Ax1(i,j+1,Nair+2)-Ax1(i,j,Nair+2))/2.d0/B_Y(j);
            Azy1(i,j)=(Az1(i,j+1,Nair+1)-Az1(i,j,Nair+1)+Az1(i+1,j+1,Nair+1)-Az1(i+1,j,Nair+1))/2.d0/B_Y(j);
            Ayz1(i,j)=(Ay1(i+1,j,Nair+2)-Ay1(i+1,j,Nair+1)+Ay1(i,j,Nair+2)-Ay1(i,j,Nair+1))/2.d0/C_Z(Nair+1);
            Exx0(i,j)=(sqrt(-1)*w).*(((Ax1(i,j+1,Nair+1)+Ax1(i,j,Nair+1))/2.d0+(Ax1(i,j+1,Nair+2)+Ax1(i,j,Nair+2))/2.d0)/2.d0+((PHI1(i+1,j,Nair+1)-PHI1(i,j,Nair+1))/A_X(i)+(PHI1(i+1,j+1,Nair+1)-PHI1(i,j+1,Nair+1))/A_X(i))/2); %  ���Ĵų�ȡΪ��Ԫ�ĸ��ڵ�ų���ƽ��ֵ
            Eyy0(i,j)=(sqrt(-1)*w).*(((Ay1(i,j,Nair+1)+Ay1(i+1,j,Nair+1))/2.d0+(Ay1(i,j,Nair+2)+Ay1(i+1,j,Nair+2))/2.d0)/2.d0+((PHI1(i,j+1,Nair+1)-PHI1(i,j,Nair+1))/B_Y(j)+(PHI1(i+1,j+1,Nair+1)-PHI1(i+1,j,Nair+1))/B_Y(j))/2); %  ���Ĵų�ȡΪ��Ԫ�ĸ��ڵ�ų���ƽ��ֵ
            Hyy0(i,j)=( Axz1(i,j)- Azx1(i,j))/((mu));%  
            Hxx0(i,j)=( Azy1(i,j)- Ayz1(i,j))/((mu));           
        end
    end
    
    Exx1=interp2(xy{1,1},xy{1,2},Exx0.',xy0{1,1},xy0{1,2},'spline');
    Hxx1=interp2(xy{1,1},xy{1,2},Hxx0.',xy0{1,1},xy0{1,2},'spline');
    Eyy1=interp2(xy{1,1},xy{1,2},Eyy0.',xy0{1,1},xy0{1,2},'spline');
    Hyy1=interp2(xy{1,1},xy{1,2},Hyy0.',xy0{1,1},xy0{1,2},'spline');
end