function [xy,xy0,nx,ny]=get_location(a_x,b_y,x,y)
 %input:
 % a_x: The length of each unit in x direction
 % b_y: The length of each unit in y direction
 %x and y are the coordinate of measuring point along x and y directions
 %output
 % xy0  are coordinate of measuring point.
 % xy  are the calculated coordinates of the area.
% 
 a_x=a_x./1000;
 b_y=b_y./1000;
 x=x./1000;
 y=y./1000;
NX=length(a_x);
NY=length(b_y);
sumx=0;

for i=1:NX
    sumx=sumx+a_x(i);
end

DX=zeros(1,NX);%
DX(1)=-sumx/2+a_x(1)/2;
for i=2:NX
    DX(1,i)=DX(1,i-1)+a_x(i-1)/2+a_x(i)/2;
end

sumy=0;
for j=1:NY
    sumy=sumy+b_y(j);
end

DY=zeros(1,NY);%
DY(1)=-sumy/2+b_y(1)/2;
for i=2:NY
    DY(1,i)=DY(1,i-1)+b_y(i-1)/2+b_y(i)/2;
end
[xy{1,1},xy{1,2}]=meshgrid(DX,DY);
nx=length(x);
ny=length(y);
[xy0{1,1},xy0{1,2}]=meshgrid(x,y);


