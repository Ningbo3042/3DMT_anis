function [Ex1,Ex2,Ey1,Ey2]=get_boundary(NX,NY,NZ,C_Z,rho,freq,alpha_S,alpha_D,alpha_L)
% Input
% NX: The numbers in x direction
% NY: The numbers in y direction
% NZ: The numbers in z direction
% C_Z: The length of each unit in z direction
% Nair: Number of air layers
% rho(:,1:3) are the three principal axis resistivity of all elements, respectively
% angle_S,angle_D,angle_L are the three Euler angles of all elements, respectively
% fre are the computational frequencies
% Output
% Ex1,Ex2,Ey1,and Ey2 are EM fields obtained by 1D analytical solution of electric field, respectively
zNode = [0 cumsum(C_Z)];
rho_xx=reshape(rho(:,1), NX, NY, NZ);
rho_yy=reshape(rho(:,2), NX, NY, NZ);
rho_zz=reshape(rho(:,3), NX, NY, NZ);
alpha_Sx=reshape(alpha_S, NX, NY, NZ);
alpha_Dy=reshape(alpha_D, NX, NY, NZ);
alpha_Lz=reshape(alpha_L, NX, NY, NZ);
alpha_S=alpha_Sx(1,1,1:end);
alpha_D=alpha_Dy(1,1,1:end);
alpha_L=alpha_Lz(1,1,1:end);
res=[vet(rho_xx(1,1,1:end)) vet(rho_yy(1,1,1:end)) vet(rho_zz(1,1,1:end))];

for h=1:NZ
sigma_primary=[1/res(h,1) 0 0; 0 1/res(h,2) 0; 0 0 1/res(h,3)];
RzfuAlpha_S=[cos(-alpha_S(h)) sin(-alpha_S(h)) 0; -sin(-alpha_S(h)) cos(-alpha_S(h)) 0; 0 0 1]; 
RxfuAlpha_D=[1 0 0; 0 cos(-alpha_D(h)) sin(-alpha_D(h)); 0 -sin(-alpha_D(h)) cos(-alpha_D(h))]; 
RzfuAlpha_L=[cos(-alpha_L(h)) sin(-alpha_L(h)) 0; -sin(-alpha_L(h)) cos(-alpha_L(h)) 0; 0 0 1]; 
RzAlpha_L=[cos(alpha_L(h)) sin(alpha_L(h)) 0; -sin(alpha_L(h)) cos(alpha_L(h)) 0; 0 0 1]; 
RxAlpha_D=[1 0 0; 0 cos(alpha_D(h)) sin(alpha_D(h)); 0 -sin(alpha_D(h)) cos(alpha_D(h))]; 
RzAlpha_S=[cos(alpha_S(h)) sin(alpha_S(h)) 0; -sin(alpha_S(h)) cos(alpha_S(h)) 0; 0 0 1]; 
sigma_tensor=RzfuAlpha_S*RxfuAlpha_D*RzfuAlpha_L*sigma_primary*RzAlpha_L*RxAlpha_D*RzAlpha_S;
sigma_xx(h)=sigma_tensor(1,1);
sigma_xy(h)=sigma_tensor(1,2); 
sigma_xz(h)=sigma_tensor(1,3); 
sigma_yx(h)=sigma_tensor(2,1); 
sigma_yy(h)=sigma_tensor(2,2); 
sigma_yz(h)=sigma_tensor(2,3); 
sigma_zx(h)=sigma_tensor(3,1); 
sigma_zy(h)=sigma_tensor(3,2); 
sigma_zz(h)=sigma_tensor(3,3); 
end
sig1D = [sigma_xx', sigma_yy', sigma_zz', sigma_xy', sigma_xz', sigma_yz'];
[Ex1,Ey1,Ez1]=mt1DAniAnalyticField(freq,sig1D,zNode,[1.0; 0]);
[Ex2,Ey2,Ez2]=mt1DAniAnalyticField(freq,sig1D,zNode,[0; 1.0]);
